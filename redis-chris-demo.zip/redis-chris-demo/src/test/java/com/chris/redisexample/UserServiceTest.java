package com.chris.redisexample;


import com.chris.redisexample.LatLanAtl;
import com.chris.redisexample.TerrestrialObject;
import com.chris.redisexample.TerrestrialObjectType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class UserServiceTest {

    @Mock
    private RedisTemplate<String, Object> redisTemplate;

    @Mock
    private ValueOperations<String, Object> valueOperations;

    @InjectMocks
    private UserService userService;

    private TerrestrialObject object;

    @BeforeEach
    void setUp() {
        LatLanAtl location = new LatLanAtl(10.0,20.0,30.0);
        object = new TerrestrialObject("1", "Test Planet", TerrestrialObjectType.PLANET, location);
    }

    @Test
    void testSaveObject() {
        when(redisTemplate.opsForValue()).thenReturn(valueOperations);
        //when(valueOperations.set(object.getId(), object)).thenReturn(null);

        TerrestrialObject savedObject = userService.saveObject(object);
        assertEquals(object, savedObject);
        verify(redisTemplate, times(1)).opsForValue();
        verify(valueOperations,times(1)).set(object.getId(),object);
    }

    @Test
    void testUpdateObject_ObjectExists() {
        when(redisTemplate.opsForValue()).thenReturn(valueOperations);
        when(redisTemplate.hasKey(object.getId())).thenReturn(true);
        //when(valueOperations.set(object.getId(),object)).thenReturn(null);

        TerrestrialObject updatedObject = userService.updateObject(object);

        assertEquals(object, updatedObject);
        verify(redisTemplate, times(1)).hasKey(object.getId());
        verify(redisTemplate, times(1)).opsForValue();
        verify(valueOperations, times(1)).set(object.getId(),object);
    }

    @Test
    void testUpdateObject_ObjectNotFound() {
        when(redisTemplate.hasKey(object.getId())).thenReturn(false);

        assertThrows(IllegalArgumentException.class, () -> userService.updateObject(object));

        verify(redisTemplate, times(1)).hasKey(object.getId());
        verify(valueOperations, never()).set(any(),any());
    }

    @Test
    void testGetObjectById() {
        when(redisTemplate.opsForValue()).thenReturn(valueOperations);
        when(valueOperations.get("1")).thenReturn(object);

        Optional<TerrestrialObject> retrievedObject = userService.getObjectById("1");

        assertTrue(retrievedObject.isPresent());
        assertEquals(object, retrievedObject.get());
        verify(redisTemplate,times(1)).opsForValue();
        verify(valueOperations,times(1)).get("1");
    }

    @Test
    void testGetObjectById_ObjectNotFound() {
        when(redisTemplate.opsForValue()).thenReturn(valueOperations);
        when(valueOperations.get("1")).thenReturn(null);

        Optional<TerrestrialObject> retrievedObject = userService.getObjectById("1");
        assertFalse(retrievedObject.isPresent());

        verify(redisTemplate,times(1)).opsForValue();
        verify(valueOperations,times(1)).get("1");
    }

    @Test
    void testDeleteObject() {
        doNothing().when(redisTemplate).delete("1");

        userService.deleteObject("1");

        verify(redisTemplate, times(1)).delete("1");
    }
}