package com.chris.redisexample;


import com.chris.redisexample.LatLanAtl;
import com.chris.redisexample.TerrestrialObject;
import com.chris.redisexample.TerrestrialObjectType;
import com.chris.redisexample.UserService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
//import org.springframework.boot.test.mock.mockito.MockBean;
//import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(UserController.class)
public class UserControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Mock
    private UserService userService;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void testSaveObject() throws Exception {
        LatLanAtl location = new LatLanAtl(10.0,20.0,30.0);
        TerrestrialObject object = new TerrestrialObject("1", "Test Object", TerrestrialObjectType.PLANET, location);
        when(userService.saveObject(any(TerrestrialObject.class))).thenReturn(object);

        mockMvc.perform(post("/objects")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(object)))
                .andExpect(status().isCreated())
                .andExpect(content().json(objectMapper.writeValueAsString(object)));

        verify(userService, times(1)).saveObject(any(TerrestrialObject.class));
    }

    @Test
    void testUpdateObject() throws Exception {
        LatLanAtl location = new LatLanAtl(10.0,20.0,30.0);
        TerrestrialObject object = new TerrestrialObject("1", "Updated Object", TerrestrialObjectType.PLANET, location);
        when(userService.updateObject(any(TerrestrialObject.class))).thenReturn(object);

        mockMvc.perform(put("/objects")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(object)))
                .andExpect(status().isOk())
                .andExpect(content().json(objectMapper.writeValueAsString(object)));

        verify(userService, times(1)).updateObject(any(TerrestrialObject.class));
    }

    @Test
    void testGetObjectById() throws Exception {
        LatLanAtl location = new LatLanAtl(10.0,20.0,30.0);
        TerrestrialObject object = new TerrestrialObject("1", "Test Object", TerrestrialObjectType.PLANET, location);

        when(userService.getObjectById("1")).thenReturn(Optional.of(object));

        mockMvc.perform(get("/objects/1"))
                .andExpect(status().isOk())
                .andExpect(content().json(objectMapper.writeValueAsString(object)));

        verify(userService, times(1)).getObjectById("1");
    }

    @Test
    void testGetObjectByIdNotFound() throws Exception {
        when(userService.getObjectById("1")).thenReturn(Optional.empty());

        mockMvc.perform(get("/objects/1"))
                .andExpect(status().isNotFound());

        verify(userService, times(1)).getObjectById("1");
    }

    @Test
    void testDeleteObject() throws Exception {
        doNothing().when(userService).deleteObject("1");

        mockMvc.perform(delete("/objects/1"))
                .andExpect(status().isNoContent());

        verify(userService, times(1)).deleteObject("1");
    }
}