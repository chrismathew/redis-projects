package com.chris.redisexample;

public enum TerrestrialObjectType {
    PLANET,
    MOON,
    ASTEROID,
    COMET
}