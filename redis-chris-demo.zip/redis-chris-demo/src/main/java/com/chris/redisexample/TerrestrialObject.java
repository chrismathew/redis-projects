package com.chris.redisexample;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TerrestrialObject implements Serializable {

    @Id
    private String id;
    private String name;
    private TerrestrialObjectType type;
    private LatLanAtl location;
}