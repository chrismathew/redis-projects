package com.chris.redisexample;

import com.chris.redisexample.LatLanAtl;
import com.chris.redisexample.TerrestrialObject;
import com.chris.redisexample.TerrestrialObjectType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.testcontainers.containers.GenericContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;
import org.testcontainers.utility.DockerImageName;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@Testcontainers
public class RedisIntegrationTest {

    @LocalServerPort
    private int port;

    @Autowired
    private TestRestTemplate restTemplate;
    @Autowired
    private RedisTemplate<String, Object> redisTemplate;
    private ValueOperations<String, Object> valueOperations;



    @Container
    private static final GenericContainer<?> redis =
            new GenericContainer<>(DockerImageName.parse("redis:latest"))
                    .withExposedPorts(6379);

    @BeforeEach
    void setup() {
        System.setProperty("spring.data.redis.host", redis.getHost());
        System.setProperty("spring.data.redis.port", String.valueOf(redis.getFirstMappedPort()));
        valueOperations= redisTemplate.opsForValue();
    }

    @Test
    public void testSaveObject() {
        LatLanAtl location = new LatLanAtl(10.0,20.0,30.0);
        TerrestrialObject object = new TerrestrialObject("1", "Integration Test Object", TerrestrialObjectType.PLANET, location);

        ResponseEntity<TerrestrialObject> response = restTemplate.postForEntity("http://localhost:" + port + "/objects", object, TerrestrialObject.class);

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.CREATED);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().getId()).isEqualTo("1");

        TerrestrialObject savedObject= (TerrestrialObject) valueOperations.get("1");
        assertThat(savedObject).isNotNull();
    }

    @Test
    void testUpdateObject() {
        LatLanAtl location = new LatLanAtl(10.0,20.0,30.0);
        TerrestrialObject initialObject = new TerrestrialObject("1", "Initial Object", TerrestrialObjectType.PLANET,location);
        valueOperations.set("1",initialObject);
        LatLanAtl locationUpdated = new LatLanAtl(15.0,25.0,35.0);
        TerrestrialObject updatedObject = new TerrestrialObject("1", "Updated Object", TerrestrialObjectType.PLANET,locationUpdated);

        restTemplate.put("http://localhost:" + port + "/objects", updatedObject);

        TerrestrialObject retrievedObject = (TerrestrialObject) valueOperations.get("1");
        assertThat(retrievedObject).isNotNull();
        assertThat(retrievedObject.getName()).isEqualTo("Updated Object");
        assertThat(retrievedObject.getLocation().getAltitude()).isEqualTo(35.0);
    }

    @Test
    void testGetObjectById() {
        LatLanAtl location = new LatLanAtl(10.0,20.0,30.0);
        TerrestrialObject object = new TerrestrialObject("1","Test Object",TerrestrialObjectType.PLANET,location);
        valueOperations.set("1",object);

        ResponseEntity<TerrestrialObject> response = restTemplate.getForEntity("http://localhost:" + port + "/objects/1", TerrestrialObject.class);

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().getId()).isEqualTo("1");
        assertThat(response.getBody().getName()).isEqualTo("Test Object");
    }

    @Test
    void testDeleteObject() {
        LatLanAtl location = new LatLanAtl(10.0,20.0,30.0);
        TerrestrialObject object = new TerrestrialObject("1","Test Object",TerrestrialObjectType.PLANET,location);
        valueOperations.set("1",object);

        restTemplate.delete("http://localhost:" + port + "/objects/1");

        TerrestrialObject deletedObject = (TerrestrialObject) valueOperations.get("1");

        assertThat(deletedObject).isNull();
    }
}