package com.chris.redisexample;



import com.chris.redisexample.TerrestrialObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserService {


    @Autowired
    private RedisTemplate<String, Object> redisTemplate;

    public TerrestrialObject saveObject(TerrestrialObject object) {
        redisTemplate.opsForValue().set(object.getId(), object);
        return object;
    }

    public TerrestrialObject updateObject(TerrestrialObject object) {
        if (redisTemplate.hasKey(object.getId())) {
            redisTemplate.opsForValue().set(object.getId(),object);
            return object;
        } else {
            throw new IllegalArgumentException("Object not found with id:" + object.getId());
        }
    }

    public Optional<TerrestrialObject> getObjectById(String id) {
        TerrestrialObject object = (TerrestrialObject) redisTemplate.opsForValue().get(id);
        return Optional.ofNullable(object);
    }

    public void deleteObject(String id) {
        redisTemplate.delete(id);
    }
}