package com.chris.redisexample;

import org.springframework.boot.SpringApplication;

public class TestRedisChrisDemoApplication {

	public static void main(String[] args) {
		SpringApplication.from(RedisChrisDemoApplication::main).with(TestcontainersConfiguration.class).run(args);
	}

}
