package com.chris.example.redis_demo;



import com.chris.example.redis_demo.RedisService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/redis")
public class RedisController {

    @Autowired
    private RedisService redisService;

    @PostMapping("/save")
    public String saveData(@RequestParam String key, @RequestParam String value) {
        redisService.saveData(key, value);
        return "Data saved!";
    }

    @GetMapping("/get")
    public String getData(@RequestParam String key) {
        return redisService.getData(key);
    }

    @PostMapping("/update")
    public String updateData(@RequestParam String key, @RequestParam String value) {
        redisService.updateData(key, value);
        return "Data updated!";
    }
}
