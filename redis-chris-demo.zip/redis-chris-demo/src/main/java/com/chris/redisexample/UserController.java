package com.chris.redisexample;



import com.chris.redisexample.TerrestrialObject;
import com.chris.redisexample.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/objects")
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping
    public ResponseEntity<TerrestrialObject> saveObject(@RequestBody TerrestrialObject object) {
        TerrestrialObject savedObject = userService.saveObject(object);
        return new ResponseEntity<>(savedObject, HttpStatus.CREATED);
    }

    @PutMapping
    public ResponseEntity<TerrestrialObject> updateObject(@RequestBody TerrestrialObject object) {
        TerrestrialObject updatedObject = userService.updateObject(object);
        return ResponseEntity.ok(updatedObject);
    }

    @GetMapping("/{id}")
    public ResponseEntity<TerrestrialObject> getObjectById(@PathVariable String id) {
        Optional<TerrestrialObject> object = userService.getObjectById(id);
        return object.map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteObject(@PathVariable String id) {
        userService.deleteObject(id);
        return ResponseEntity.noContent().build();
    }
}